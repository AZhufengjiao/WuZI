// jwt 机密字符串
module.exports.jwtSecret = 'wuzi_token'

// 用户信息密码加密字符串
module.exports.passwordSectet = 'wuzi_password'